function [R_cc_est,t_cc_est]=efficient_pnp_gauss_cc(A1,x3d_h,x2d_h,x3d_h2,x2d_h2,delta_R2,delta_t2,x3d_h3,x2d_h3,delta_R3,delta_t3,...
    x3d_h4,x2d_h4,delta_R4,delta_t4)
tic

Xw=x3d_h(:,1:3);
U=x2d_h(:,1:2);

THRESHOLD_REPROJECTION_ERROR=20;%error in degrees of the basis formed by the control points. 
%If we have a larger error, we will compute the solution using a larger
%number of vectors in the kernel

%define control points in a world coordinate system (centered on the 3d
%points centroid)
Cw=define_control_points();

%compute alphas (linear combination of the control points to represent the 3d
%points)
%% ��һ�����
Alph=compute_alphas(Xw,Cw);
%Compute M
M=compute_M_ver2(U,Alph,A1);


%% �ڶ������
Xw2=x3d_h2(:,1:3);
U2=x2d_h2(:,1:2);
Alph2=compute_alphas(Xw2,Cw);
[M2,b2]=compute_M_ver2_new_version(U2,Alph2,A1,delta_R2,delta_t2);
%% ���������
Xw3=x3d_h3(:,1:3);
U3=x2d_h3(:,1:2);
Alph3=compute_alphas(Xw3,Cw);
[M3,b3]=compute_M_ver2_new_version(U3,Alph3,A1,delta_R3,delta_t3);
%% ���ĸ����
Xw4=x3d_h4(:,1:3);
U4=x2d_h4(:,1:2);
Alph4=compute_alphas(Xw4,Cw);
[M4,b4]=compute_M_ver2_new_version(U4,Alph4,A1,delta_R4,delta_t4);
%%
MM=[M  zeros(size(M,1),1);M2,b2; M3,b3;M4,b4  ];
%Compute kernel M
Km=kernel_noise_cc(MM,6); %in matlab we have directly the funcion km=null(M);
    
% T1=toc
    
%% ����REPPnP�㷨����λ�˵���
% toc
[R_cc_est,t_cc_est] = KernelPnP_cc(Cw', Km(1:12,:), 4, 1);
% T2=toc
tic



%% ����С���˷�
P_new=R_cc_est*x3d_h';
M=[];b=[];
for i=1:size(x2d_h,1)
    M=[M;1 0 -x2d_h(i,1); 0   1    -x2d_h(i,2)];
    
    b=[b;  P_new(3,i)*x2d_h(i,1)-P_new(1,i);   P_new(3,i)*x2d_h(i,2)-P_new(2,i) ];
end
t=(M'*M)^-1*M'*b;

%
P_new2=R_cc_est*x3d_h2'+delta_R2'*delta_t2;
u_new2=delta_R2'*[x2d_h2';ones(1,size(x2d_h2,1))];
n2=size(u_new2,2);
M2=[u_new2(3,:)',zeros(n2,1) ,-u_new2(1,:)';
    zeros(n2,1), u_new2(3,:)',-u_new2(2,:)'];
b2=[u_new2(1,:)'.*P_new2(3,:)'-u_new2(3,:)'.*P_new2(1,:)';
    u_new2(2,:)'.*P_new2(3,:)'-u_new2(3,:)'.*P_new2(2,:)'];
% t=(M2'*M2)^-1*M2'*b2
% M2=[];       b2=[];
% for i=1:size(x2d_h2,1)
%     M2=[M2;u_new2(3,i) 0 -u_new2(1,i); 0   u_new2(3,i)    -u_new2(2,i)];
%     
%     b2=[b2;  u_new2(1,i)*P_new2(3,i)-u_new2(3,i)*P_new2(1,i);   u_new2(2,i)*P_new2(3,i)-u_new2(3,i)*P_new2(2,i) ];
% end
% t=(M2'*M2)^-1*M2'*b2

%
P_new3=R_cc_est*x3d_h3'+delta_R3'*delta_t3;
u_new3=delta_R3'*[x2d_h3';ones(1,size(x2d_h3,1))];
n3=size(u_new3,2);
M3=[u_new3(3,:)',zeros(n3,1) ,-u_new3(1,:)';
    zeros(n3,1), u_new3(3,:)',-u_new3(2,:)'];
b3=[u_new3(1,:)'.*P_new3(3,:)'-u_new3(3,:)'.*P_new3(1,:)';
    u_new3(2,:)'.*P_new3(3,:)'-u_new3(3,:)'.*P_new3(2,:)'];
% M3=[];       b3=[];
% for i=1:size(x2d_h3,1)
%     M3=[M3;u_new3(3,i) 0 -u_new3(1,i); 0   u_new3(3,i)    -u_new3(2,i)];
%     
%     b3=[b3;  u_new3(1,i)*P_new3(3,i)-u_new3(3,i)*P_new3(1,i);   u_new3(2,i)*P_new3(3,i)-u_new3(3,i)*P_new3(2,i) ];
% end
% t=(M3'*M3)^-1*M3'*b3;
%
P_new4=R_cc_est*x3d_h4'+delta_R4'*delta_t4;
u_new4=delta_R4'*[x2d_h4';ones(1,size(x2d_h4,1))];
n4=size(u_new4,2);
M4=[u_new4(3,:)',zeros(n4,1) ,-u_new4(1,:)';
    zeros(n4,1), u_new4(3,:)',-u_new4(2,:)'];
b4=[u_new4(1,:)'.*P_new4(3,:)'-u_new4(3,:)'.*P_new4(1,:)';
    u_new4(2,:)'.*P_new4(3,:)'-u_new4(3,:)'.*P_new4(2,:)'];
% M4=[];       b4=[];
% for i=1:size(x2d_h4,1)
%     M4=[M4;u_new4(3,i) 0 -u_new4(1,i); 0   u_new4(3,i)    -u_new4(2,i)];
%     
%     b4=[b4;  u_new4(1,i)*P_new4(3,i)-u_new4(3,i)*P_new4(1,i);   u_new4(2,i)*P_new4(3,i)-u_new4(3,i)*P_new4(2,i) ];
% end
% t=(M4'*M4)^-1*M4'*b4;

M_all=[M;M2;M3;M4];
b_all=[b;b2;b3;b4];
t_cc_est=(M_all'*M_all)^-1*M_all'*b_all;
% T2=toc
a=1;
%    %%    ��LHM
%    %��һ�����
%    n1=size(x3d_h,1);x2d_h=[x2d_h';ones(1,n1)];
%     V1(1:3,1:3,1:n1)=0;B1=zeros(3,1);
%     for i=1:n1
%         V1(:,:,i)=x2d_h(:,i)*x2d_h(:,i)'/(x2d_h(:,i)'*x2d_h(:,i));
%         B1=B1+(V1(:,:,i)-eye(3))*R_cc_est*x3d_h(i,:)';
%     end
% %     t_est=inv( n1*eye(3)-sum(V1,3))*B1;
%     %�ڶ������
%     n2=size(x3d_h2,1);x2d_h2=[x2d_h2';ones(1,n2)];
%     V2(1:3,1:3,1:n2)=0;B2=zeros(3,1);
%     for i=1:n2
%         V2(:,:,i)=x2d_h2(:,i)*x2d_h2(:,i)'/(x2d_h2(:,i)'*x2d_h2(:,i));
%         B2=B2+delta_R2'*(V2(:,:,i)-eye(3))*(   delta_R2*R_cc_est*x3d_h2(i,:)'+delta_t2);
%     end
% %     t_est2=inv(  size(x3d_h2,1)*eye(3)-sum(V2,3)    )*B2;
%     %���������
%     n3=size(x3d_h3,1);x2d_h3=[x2d_h3';ones(1,n3)];
%     V3(1:3,1:3,1:n3)=0;B3=zeros(3,1);
%     for i=1:n3
%         V3(:,:,i)=x2d_h3(:,i)*x2d_h3(:,i)'/(x2d_h3(:,i)'*x2d_h3(:,i));
%         %
%         B3=B3+delta_R3'*(V3(:,:,i)-eye(3))*(   delta_R3*R_cc_est*x3d_h3(i,:)'+delta_t3);
%     end
% %     t_est3=inv(  size(x3d_h3,1)*eye(3)-sum(V3,3)    )*B3;
%     %���ĸ����
%     n4=size(x3d_h4,1);x2d_h4=[x2d_h4';ones(1,n4)];
%     V4(1:3,1:3,1:size(x3d_h4,1))=0;B4=zeros(3,1);
%     for i=1:n4
%         V4(:,:,i)=x2d_h4(:,i)*x2d_h4(:,i)'/(x2d_h4(:,i)'*x2d_h4(:,i));
%         B4=B4+delta_R4'*(V4(:,:,i)-eye(3))*(   delta_R4*R_cc_est*x3d_h4(i,:)'+delta_t4);
%     end
% %     t_est4=inv(  n4*eye(3)-sum(V4,3)    )*B4;
%     
%     t_cc_est=(  (  n1+n2+n3+n4 )*eye(3)-sum(V1,3)-sum(V2,3)-sum(V3,3)-sum(V4,3))\...
%              (B1+B2+B3+B4);
%     T3=toc
end