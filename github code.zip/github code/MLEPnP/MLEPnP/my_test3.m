function [R_final,T_final] = my_test3(A,Cw,M,x3d_h2,x2d_h2,delta_R2,delta_t2,x3d_h3,x2d_h3,delta_R3,delta_t3,x3d_h4,x2d_h4,delta_R4,delta_t4)
    
    %% �ڶ������
    Xw2=x3d_h2(:,1:3);
    U2=x2d_h2(:,1:2);
    Alph2=compute_alphas(Xw2,Cw);
    [M2,b2]=compute_M_ver2_new_version(U2,Alph2,A,delta_R2,delta_t2);
    %% ���������
    Xw3=x3d_h3(:,1:3);
    U3=x2d_h3(:,1:2);
    Alph3=compute_alphas(Xw3,Cw);
    [M3,b3]=compute_M_ver2_new_version(U3,Alph3,A,delta_R3,delta_t3);
    %% ���ĸ����
    Xw4=x3d_h4(:,1:3);
    U4=x2d_h4(:,1:2);
    Alph4=compute_alphas(Xw4,Cw);
    [M4,b4]=compute_M_ver2_new_version(U4,Alph4,A,delta_R4,delta_t4);
    %%
    MM=[M  zeros(size(M,1),1);M2,b2; M3,b3;M4,b4  ];
    %Compute kernel M
    Km=kernel_noise_cc(MM,6); %in matlab we have directly the funcion km=null(M);
    
    
    
    %% ����REPPnP�㷨����λ�˵���
    [R_final,T_final] = KernelPnP_cc(Cw', Km(1:12,:), 4, 1);
%          AAAAAA=[M;M2];bbbbb=[zeros(size(M,1),1);b2];
%     X1=inv(AAAAAA'*AAAAAA)*AAAAAA'*bbbbb;
%     [R2,T2, err] = KernelPnP_cc(Cw',X1, 4, 1);
    
    V=[];
    A=zeros(3);B=zeros(3,1);
    for i=1:size(x3d_h2,1)
        v_i=[x2d_h2(i,:),1]';
        V(:,:,i)=v_i*v_i'/(v_i'*v_i);
        %
        B=B+(V(:,:,i)-eye(3))*R_final*x3d_h2(i,:)';
        A=A+V(:,:,i);
    end
    n=size(x3d_h2,1);
    t_est=1/n*inv(  eye(3)-1/n*A    )*B
    

end

