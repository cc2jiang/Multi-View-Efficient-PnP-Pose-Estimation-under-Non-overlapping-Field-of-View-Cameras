function [R_cc_est,t_cc_est] = MLEPnP_outlier(XX,xx,XX2,xx2,delta_R2,delta_t2,XX3,xx3,delta_R3,delta_t3,XX4,xx4,delta_R4,delta_t4)

[R_cc_est,t_cc_est]= efficient_pnp_gauss_cc_outlier(diag([1 1 1]),XX.',xx.',XX2.',xx2.',delta_R2,delta_t2,XX3.',xx3.',delta_R3,delta_t3,XX4.',xx4.',delta_R4,delta_t4);

return