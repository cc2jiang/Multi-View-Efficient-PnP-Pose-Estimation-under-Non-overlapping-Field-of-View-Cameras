function [R_cc_est,t_cc_est]=efficient_pnp_gauss_cc_outlier(A1,x3d_h,x2d_h,x3d_h2,x2d_h2,delta_R2,delta_t2,x3d_h3,x2d_h3,delta_R3,delta_t3,...
    x3d_h4,x2d_h4,delta_R4,delta_t4)
tic

Xw=x3d_h(:,1:3);
U=x2d_h(:,1:2);

THRESHOLD_REPROJECTION_ERROR=20;%error in degrees of the basis formed by the control points. 
%If we have a larger error, we will compute the solution using a larger
%number of vectors in the kernel

%define control points in a world coordinate system (centered on the 3d
%points centroid)
Cw=define_control_points();

%compute alphas (linear combination of the control points to represent the 3d
%points)
%% first camera
Alph=compute_alphas(Xw,Cw);
%Compute M
M=compute_M_ver2(U,Alph,A1);


%% second camera
Xw2=x3d_h2(:,1:3);
U2=x2d_h2(:,1:2);
Alph2=compute_alphas(Xw2,Cw);
[M2,b2]=compute_M_ver2_new_version(U2,Alph2,A1,delta_R2,delta_t2);
%% third camera
Xw3=x3d_h3(:,1:3);
U3=x2d_h3(:,1:2);
Alph3=compute_alphas(Xw3,Cw);
[M3,b3]=compute_M_ver2_new_version(U3,Alph3,A1,delta_R3,delta_t3);
%% fourth camera
Xw4=x3d_h4(:,1:3);
U4=x2d_h4(:,1:2);
Alph4=compute_alphas(Xw4,Cw);
[M4,b4]=compute_M_ver2_new_version(U4,Alph4,A1,delta_R4,delta_t4);
%%
MM=[M  zeros(size(M,1),1);M2,b2; M3,b3;M4,b4  ];


minerror = 0.02; %for the synthetic experiments (f = 800)
[Km, idinliers, ~] = my_robust_kernel_noise_cc2(MM,6,minerror);
% T1=toc
    
%% REPPnP
% toc
[R_cc_est,~] = KernelPnP_cc(Cw', Km(1:12,:), 4, 1);
% T2=toc
tic


%%  chosen
idinliers=sort(idinliers);



idinliers1=idinliers(idinliers > 0 & idinliers <= size(x3d_h,1));
x3d_h_update=x3d_h(idinliers1,:);    x2d_h_update=x2d_h(idinliers1,:);

%
low_bound2=size(x3d_h,1);    upper_bound2=(size(x3d_h,1)+size(x3d_h2,1));
idinliers2=idinliers(idinliers >low_bound2  & idinliers <=upper_bound2 )   -low_bound2;
x3d_h2_update=x3d_h2(idinliers2,:);    x2d_h2_update=x2d_h2(idinliers2,:);
%
low_bound3=upper_bound2;     upper_bound3=size(x3d_h,1)+size(x3d_h2,1)+size(x3d_h3,1);
idinliers3=idinliers(idinliers > low_bound3 & idinliers <= upper_bound3)     -low_bound3;
x3d_h3_update=x3d_h3(idinliers3,:);    x2d_h3_update=x2d_h3(idinliers3,:);
%
low_bound4=upper_bound3;     upper_bound4=size(x3d_h,1)+size(x3d_h2,1)+size(x3d_h3,1)+size(x3d_h4,1);
idinliers4=idinliers(idinliers > low_bound4 & idinliers <= upper_bound4)    -low_bound4;
x3d_h4_update=x3d_h4(idinliers4,:);    x2d_h4_update=x2d_h4(idinliers4,:);

%% LS
P_new=R_cc_est*x3d_h_update';
M=[];b=[];
for i=1:size(x2d_h_update,1)
    M=[M;1 0 -x2d_h_update(i,1); 0   1    -x2d_h_update(i,2)];
    b=[b;  P_new(3,i)*x2d_h_update(i,1)-P_new(1,i);   P_new(3,i)*x2d_h_update(i,2)-P_new(2,i) ];
end
t=(M'*M)^-1*M'*b;

%
P_new2=R_cc_est*x3d_h2_update'+delta_R2'*delta_t2;
u_new2=delta_R2'*[x2d_h2_update';ones(1,size(x2d_h2_update,1))];
n2=size(u_new2,2);
M2=[u_new2(3,:)',zeros(n2,1) ,-u_new2(1,:)';
    zeros(n2,1), u_new2(3,:)',-u_new2(2,:)'];
b2=[u_new2(1,:)'.*P_new2(3,:)'-u_new2(3,:)'.*P_new2(1,:)';
    u_new2(2,:)'.*P_new2(3,:)'-u_new2(3,:)'.*P_new2(2,:)'];
%
P_new3=R_cc_est*x3d_h3_update'+delta_R3'*delta_t3;
u_new3=delta_R3'*[x2d_h3_update';ones(1,size(x2d_h3_update,1))];
n3=size(u_new3,2);
M3=[u_new3(3,:)',zeros(n3,1) ,-u_new3(1,:)';
    zeros(n3,1), u_new3(3,:)',-u_new3(2,:)'];
b3=[u_new3(1,:)'.*P_new3(3,:)'-u_new3(3,:)'.*P_new3(1,:)';
    u_new3(2,:)'.*P_new3(3,:)'-u_new3(3,:)'.*P_new3(2,:)'];
%
P_new4=R_cc_est*x3d_h4_update'+delta_R4'*delta_t4;
u_new4=delta_R4'*[x2d_h4_update';ones(1,size(x2d_h4_update,1))];
n4=size(u_new4,2);
M4=[u_new4(3,:)',zeros(n4,1) ,-u_new4(1,:)';
    zeros(n4,1), u_new4(3,:)',-u_new4(2,:)'];
b4=[u_new4(1,:)'.*P_new4(3,:)'-u_new4(3,:)'.*P_new4(1,:)';
    u_new4(2,:)'.*P_new4(3,:)'-u_new4(3,:)'.*P_new4(2,:)'];

M_all=[M;M2;M3;M4];
b_all=[b;b2;b3;b4];
t_cc_est=(M_all'*M_all)^-1*M_all'*b_all;

end