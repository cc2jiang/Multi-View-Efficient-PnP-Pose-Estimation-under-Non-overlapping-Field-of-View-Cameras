function [K, idinliers, i]=my_robust_kernel_noise_cc2(MM,dimker, minerror)
 
%     M=MM(:,1:12);b=MM(:,13);
%     x=(M'*M)^-1*M'*b;
%     figure(1)
%     plot(M*x-b)

    m   = size(MM,1);
    idx = 1:m;

    for i=1:10
    
        N = MM(idx,:);
        [~,~,v] = svd(N(:,:)'*N(:,:));
        error_one    = MM(1:2:end,:) * v(:,end);
        error_two    = MM(2:2:end,:) * v(:,end);
        error_all     = sqrt(error_one.^2 + error_two.^2);
        

        npt=size(error_all,1);
        error1=error_all(1:npt/4);
        error2=error_all(npt/4+1:npt/2);
        error3=error_all(npt/2+1:npt*3/4);
        error4=error_all(npt*3/4+1:npt);
        %%
        outlier_num=round(size(error1,1)*0.7);
        w=1000;h=200;
        
        

        [sv1, tidx1] = sort(error1);  
        med1 = sv1(floor(size(sv1,1)/8)); 
        inliers1 = tidx1(sv1<=max(med1,minerror));  
        inliers1=sort(inliers1);
        index1=[];
        for i=1:size(inliers1,1)
            index1=[index1,2*inliers1(i,1)-1,2*inliers1(i,1)];
        end
        
        [sv2, tidx2] = sort(error2);  
        med2 = sv2(floor(size(sv2,1)/8)); 
        inliers2 = tidx2(sv2<=max(med2,minerror))+npt/4; 
        inliers2=sort(inliers2);
        index2=[];
        for i=1:size(inliers2,1)
            index2=[index2,2*inliers2(i,1)-1,2*inliers2(i,1)];
        end
        
        [sv3, tidx3] = sort(error3);  
        med3 = sv3(floor(size(sv3,1)/8)); 
        inliers3 = tidx3(sv3<=max(med3,minerror))+npt/2;
        inliers3=sort(inliers3);
        index3=[];
        for i=1:size(inliers3,1)
            index3=[index3,2*inliers3(i,1)-1,2*inliers3(i,1)];
        end
        
        [sv4, tidx4] = sort(error4);  
        med4 = sv4(floor(size(sv4,1)/8)); 
        inliers4 = tidx4(sv4<=max(med4,minerror))+npt*3/4;
        inliers4=sort(inliers4);
        index4=[];
        for i=1:size(inliers4,1)
            index4=[index4,2*inliers4(i,1)-1,2*inliers4(i,1)];
        end
        
        idx=[index1,index2,index3,index4];
        
        
        resv=v;
        residx=[inliers1;inliers2;inliers3;inliers4];
    end
    
   
    
    
    
    K = resv(:,end-dimker+1:end);   
    idinliers = residx;
end