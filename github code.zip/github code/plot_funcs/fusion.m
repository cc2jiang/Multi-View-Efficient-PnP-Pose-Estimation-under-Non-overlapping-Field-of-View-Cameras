function [R1,t1]=fusion(R1,t1,R2,t2,delta_R2,delta_t2,R3,t3,delta_R3,delta_t3,R4,t4,delta_R4,delta_t4)
    
    RT2=inv([delta_R2,delta_t2;[0 0 0 1]])*[R2,t2;[0 0 0 1]];
    R2_=RT2(1:3,1:3);   t2_=RT2(1:3,4);
    
    RT3=inv([delta_R3,delta_t3;[0 0 0 1]])*[R3,t3;[0 0 0 1]];
    R3_=RT3(1:3,1:3);   t3_=RT3(1:3,4);
    
    RT4=inv([delta_R4,delta_t4;[0 0 0 1]])*[R4,t4;[0 0 0 1]];
    R4_=RT4(1:3,1:3);   t4_=RT4(1:3,4);
    
    [A1,A2,A3]=dcm2angle(R1);
    [B1,B2,B3]=dcm2angle(R2_);
    [C1,C2,C3]=dcm2angle(R3_);
    [D1,D2,D3]=dcm2angle(R4_);
    R1=angle2dcm(    (A1+B1+C1+D1)/4,  (A2+B2+C2+D2)/4,   (A3+B3+C3+D3)/4  );
    
    t1=(t1+t2_+t3_+t4_)/4;
    
    


end

