function [R1,t1]=fusion2(R1,t1,R2,t2,delta_R2,delta_t2)
    
    RT2=inv([delta_R2,delta_t2;[0 0 0 1]])*[R2,t2;[0 0 0 1]];
    R2_=RT2(1:3,1:3);   t2_=RT2(1:3,4);
    
    
    
    [A1,A2,A3]=dcm2angle(R1);
    [B1,B2,B3]=dcm2angle(R2_);
    
    R1=angle2dcm(    (A1+B1)/2,  (A2+B2)/2,   (A3+B3)/2  );
    
    t1=(t1+t2_)/2;
    
    


end

