function xdrawgraph_log(xs,yrange,method_list,field,ti,lx,ly,legendposition)
%the legend is at upper right in default
if nargin < 8
    legendposition = 1;
end

box('on');
hold('all');

p= zeros(size(method_list));
for i= 1:length(method_list)
%     p(i)= plot(xs,log(method_list(i).(field)),'marker',method_list(i).marker,...
%         'color',method_list(i).color,...
%         'markerfacecolor',method_list(i).markerfacecolor,...
%         'displayname',method_list(i).name, ...
%         'LineWidth',2,'MarkerSize',8);
    p(i)=semilogy(xs,(method_list(i).(field)),'marker',method_list(i).marker,...
        'color',method_list(i).color,...
        'markerfacecolor',method_list(i).markerfacecolor,...
        'displayname',method_list(i).name, ...
        'LineWidth',2,'MarkerSize',8);
    hold on

end
ylim(yrange);
set(gca,'YScale','log') 
xlim(xs([1 end]));
% set(gca,'xtick',xs);

title(ti,'FontSize',12,'FontName','Arial');
xlabel(lx,'FontSize',11);
ylabel(ly,'FontSize',11);
% legend(p,legendposition);
legend(p,'Location','NorthEast');
% h_legend =legend(p(1,1:6),'Location','NorthEast');
% %     legend boxoff;
%     % ���������СΪ 10
%     % h_legend.FontSize = 6;
%     ah=axes('position',get(gca,'position')+[-0.2 0 0 0],'visible','off');
%     h_legend =legend(ah,p(1,7:12),'Location','NorthEast');
% %     legend boxoff;

return


