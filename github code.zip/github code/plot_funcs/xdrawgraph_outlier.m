function xdrawgraph_outlier(npts,outlier_rate_success,yrange,method_list,field,ti,lx,ly,legendposition)
%the legend is at upper right in default
if nargin < 8
    legendposition = 1;
end

box('on');
hold('all');

p= zeros(size(outlier_rate_success,1),1);
for i= 1:size(outlier_rate_success,1)
    p(i)= plot(npts,outlier_rate_success(i,:)*100,'marker',method_list(i).marker,...
        'color',method_list(i).color,...
        'markerfacecolor',method_list(i).markerfacecolor,...
        'displayname',method_list(i).name, ...
        'LineWidth',2,'MarkerSize',8);
%        );
end
ylim(yrange);
xlim(npts([1 end-4]));
set(gca,'xtick',npts);

% title(ti,'FontSize',12,'FontName','Arial');
xlabel(lx,'FontSize',11);
ylabel(ly,'FontSize',11);
%legend(p,legendposition);
% legend(p);
legend(p,'Location','SouthEast');

return


