%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Please cite our paper when using this code:
% Haoyin Zhou, Tao Zhang, Jayender Jagadeesan, "Re-weighting and 1-Point RANSAC-Based PnP Solution to Handle Outliers", IEEE Transactions on Pattern Analysis and Machine Intelligence, 2018
%
% This program is distributed in the hope that it will be useful, but
% WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
% General Public License for more details.       
% You should have received a copy of the GNU General Public License
% along with this program. If not, see <http://www.gnu.org/licenses/>.
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear; clc;
close all;
addpath(genpath('../����r5'));

% experimental parameters
nls= [10:-2:0]; % level of noise
npt= 100; % number of points
num= 1000; % total number of trials

% compared methods
A= zeros(size(npt));
B= zeros(num,1);

name= {'LHM','EPnP+GN','RPnP', 'DLS',          'OPnP', 'ASPnP', 'SDP',    'PPnP', 'EPPnP', 'REPPnP', 'R1PPnP','RDLT', 'MVEPnP'};
f= {    @LHM,@EPnP_GN, @RPnP, @robust_dls_pnp, @OPnP, @ASPnP,   @GOP,     @PPnP,   @EPPnP,  @REPPnP, @R1PPnP_WithoutReWeighting,@RDLT_without_RANSAC  @MLEPnP};
marker= { 'x',    's',   'd',      '^',            '>',   '<',      'v',      '*',    '+',     '^',    'x','s', 'x'};
color= {[0.2,0.1,0.8],'g',  'b',    [1,0.5,0],'m',            'c',   'b',      'y',      [1,0.5,1],[0,0.5,1],   'r'  , [0.4,0.2,0.5],   'k' };
markerfacecolor=  {[0.2,0.1,0.8],'g','b',[1,0.5,0],'m',          'c',   'b',      'y',      'n',      'n',   'r', [0.4,0.2,0.5],'k'};


method_list= struct('name', name, 'f', f, 'mean_r', A, 'mean_t', A,...
    'med_r', A, 'med_t', A, 'std_r', A, 'std_t', A, 'r', B, 't', B,...
    'marker', marker, 'color', color, 'markerfacecolor', markerfacecolor);

% experiments
for i= 1:length(nls)
    
    nl=nls(i);
    fprintf('npt = %d (sg = %d px): ', npt, nl);   
    
     for k= 1:length(method_list)
        method_list(k).c = zeros(1,num);
        method_list(k).e = zeros(1,num);
        method_list(k).r = zeros(1,num);
        method_list(k).t = zeros(1,num);
    end
    
    index_fail = cell(1,length(name));
    
    for j= 1:num
        
        % camera's parameters
        f= 1000;
        
       %% generate 3d coordinates in 1st camera space
        XXw=[-761   -337   -761    -337    -665    -433   -665    -433                -221    -221     -221     -221
            125     125    321     321    174     174    272     272                 0       0        442      422
            221     221    221     221    221     221    221     221                 442     0        422      0];

        t= [998,-43,1700]';
        R= eye(3);
        Xc= [R,t;zeros(1,3),1]*[XXw;ones(1,npt)];   Xc=Xc(1:3,:);
        % projection
        xx= [Xc(1,:)./Xc(3,:); Xc(2,:)./Xc(3,:)]*f;
        randomvals = randn(2,npt);
        xxn= xx+randomvals*nl;
       %%  2st camera 
        ddd=1;
        npt2=npt; 
        XXw2=[761   337    761    337    665    433   665   433                         221       221      221     221
     125    125    321    321    174    174   272   272                          0       0        442      422
     221    221    221    221    221    221   221   221                         442     0        422      0];
        delta_t2=[-1700,-200,0]';        
        delta_R2=eye(3);
        Xc2= [delta_R2,delta_t2;[0 0 0 1]]*[R,t;[0 0 0 1]]*[XXw2;ones(1,npt2)];   Xc2=Xc2(1:3,:);
        % projection
        xx2=[Xc2(1,:)./Xc2(3,:); Xc2(2,:)./Xc2(3,:)]*f;
        randomvals = randn(2,npt2);
        xxn2= xx2+randomvals*nl;
        %%          % pose estimation
        for k= 1:length(method_list)
            try
               if strcmp(method_list(k).name, 'R1PPnP')
                   tic;
                   [R1,t1]= method_list(k).f(XXw,xxn/f);
                   [R2,t2]= method_list(k).f(XXw2,xxn2/f);
                   [R1,t1]=fusion(R1,t1,R2,t2,delta_R2,delta_t2);
                   tcost = toc;
               elseif strcmp(method_list(k).name, 'MVEPnP')
                   tic;
                   [R1,t1] = method_list(k).f(XXw,xxn/f,XXw2,xxn2/f,delta_R2,delta_t2,XXw3,xxn3/f,delta_R3,delta_t3,XXw4,xxn4/f,delta_R4,delta_t4);
                   tcost = toc;
               elseif strcmp(method_list(k).name, 'EPnP+GN')
                   tic;
                   [R1,t1] = method_list(k).f(XXw,xxn/f);
                   [R2,t2] = method_list(k).f(XXw2,xxn2/f);
                   [R3,t3] = method_list(k).f(XXw3,xxn3/f);
                   [R4,t4] = method_list(k).f(XXw4,xxn4/f);
                   [R1,t1]=fusion(R1,t1,R2,t2,delta_R2,delta_t2,R3,t3,delta_R3,delta_t3,R4,t4,delta_R4,delta_t4);
                   tcost = toc;
               elseif strcmp(method_list(k).name, 'RDLT')
                   tic;
                   [R1,t1] = method_list(k).f(XXw,xxn/f,R,t);
                   [R2,t2] = method_list(k).f(XXw2,xxn2/f,R2,t2);
                   [R3,t3] = method_list(k).f(XXw3,xxn3/f,R3,t3);
                   [R4,t4] = method_list(k).f(XXw4,xxn4/f,R4,t4);
                   [R1,t1]=fusion(R1,t1,R2,t2,delta_R2,delta_t2,R3,t3,delta_R3,delta_t3,R4,t4,delta_R4,delta_t4);
                   tcost = toc;
               elseif strcmp(method_list(k).name, 'REPPnP')
                   tic;
                   [R1,t1] = method_list(k).f(XXw,xxn/f);
                   [R2,t2] = method_list(k).f(XXw2,xxn2/f);
                   [R3,t3] = method_list(k).f(XXw3,xxn3/f);
                   [R4,t4] = method_list(k).f(XXw4,xxn4/f);
                   [R1,t1]=fusion(R1,t1,R2,t2,delta_R2,delta_t2,R3,t3,delta_R3,delta_t3,R4,t4,delta_R4,delta_t4);
                   tcost = toc;
               else
                   tic;
                   [R1,t1]= method_list(k).f(XXw,xxn/f);
                   [R2,t2]= method_list(k).f(XXw2,xxn2/f);
                   [R3,t3]= method_list(k).f(XXw3,xxn3/f);
                   [R4,t4]= method_list(k).f(XXw4,xxn4/f);
                   [R1,t1]=fusion(R1,t1,R2,t2,delta_R2,delta_t2,R3,t3,delta_R3,delta_t3,R4,t4,delta_R4,delta_t4);
                   tcost = toc;
               end
            catch
                disp(['The solver - ',method_list(k).name,' - encounters internal errors!!!']);
                %index_fail = [index_fail, j];
                index_fail{k} = [index_fail{k}, j];
                break;
            end
            
            %no solution
            if size(t1,2) < 1
                disp(['The solver - ',method_list(k).name,' - returns no solution!!!']);
                %index_fail = [index_fail, j];
                index_fail{k} = [index_fail{k}, j];
                break;
            elseif (sum(sum(sum(imag(R1).^2))>0) == size(R1,3) || sum(sum(imag(t1(:,:,1)).^2)>0) == size(t1,2))
                index_fail{k} = [index_fail{k}, j];
                continue;
            end
            %choose the solution with smallest error 
            error = inf;
            for jjj = 1:size(R1,3)
                tempy = cal_pose_err([R1(:,:,jjj) t1(:,jjj)],[R t]);
                if sum(tempy) < error
                    cost  = tcost;
                    ercorr= mean(sqrt(sum((R1(:,:,jjj) * XXw +  t1(:,jjj) * ones(1,npt) - Xc).^2)));
                    y     = tempy;
                    error = sum(tempy);
                end
            end
            
            method_list(k).c(j)= cost * 1000;
            method_list(k).e(j)= ercorr;
            method_list(k).r(j)= y(1);
            method_list(k).t(j)= y(2);
        end

        showpercent(j,num);
    end
    fprintf('\n');
    
    % save result
    for k= 1:length(method_list)
       %results without deleting solutions
            tmethod_list = method_list(k);
            method_list(k).c(index_fail{k}) = [];
            method_list(k).e(index_fail{k}) = [];
            method_list(k).r(index_fail{k}) = [];
            method_list(k).t(index_fail{k}) = [];

            % computational cost should be computed in a separated procedure as
            % in main_time.m
            
            method_list(k).pfail(i) = 100 * numel(index_fail{k})/num;
            
            method_list(k).mean_c(i)= mean(method_list(k).c);
            method_list(k).mean_e(i)= mean(method_list(k).e);
            method_list(k).med_c(i)= median(method_list(k).c);
            method_list(k).med_e(i)= median(method_list(k).e);
            method_list(k).std_c(i)= std(method_list(k).c);
            method_list(k).std_e(i)= std(method_list(k).e);

            method_list(k).mean_r(i)= mean(method_list(k).r);
            method_list(k).mean_t(i)= mean(method_list(k).t);
            method_list(k).med_r(i)= median(method_list(k).r);
            method_list(k).med_t(i)= median(method_list(k).t);
            method_list(k).std_r(i)= std(method_list(k).r);
            method_list(k).std_t(i)= std(method_list(k).t);
           
            %results deleting solutions where not all the methods finds one
            tmethod_list.c(unique([index_fail{:}])) = [];
            tmethod_list.e(unique([index_fail{:}])) = [];
            tmethod_list.r(unique([index_fail{:}])) = [];
            tmethod_list.t(unique([index_fail{:}])) = [];
            
            method_list(k).deleted_mean_c(i)= mean(tmethod_list.c);
            method_list(k).deleted_mean_e(i)= mean(tmethod_list.e);
            method_list(k).deleted_med_c(i)= median(tmethod_list.c);
            method_list(k).deleted_med_e(i)= median(tmethod_list.e);
            method_list(k).deleted_std_c(i)= std(tmethod_list.c);
            method_list(k).deleted_std_e(i)= std(tmethod_list.e);

            method_list(k).deleted_mean_r(i)= mean(tmethod_list.r);
            method_list(k).deleted_mean_t(i)= mean(tmethod_list.t);
            method_list(k).deleted_med_r(i)= median(tmethod_list.r);
            method_list(k).deleted_med_t(i)= median(tmethod_list.t);
            method_list(k).deleted_std_r(i)= std(tmethod_list.r);
            method_list(k).deleted_std_t(i)= std(tmethod_list.t);
    end
end

% save ../results/ordinary3DresultsNpts method_list npts;

plotOrdinary3Dsigmas;

% saveas(9, '../results/figure10(a).png');
